# PROJECT_STATE.v12.md

# Cottageboard Project State v12

현재 방에서 진행한 구조 안정화 작업 요약.

---

## 0. 이번 방 핵심

전체 시스템 구조점검을 이어가며, 기존 의도를 복원하고 실제 구현과 맞지 않는 부분만 고치는 방향으로 정리했다.

처음에는 일부 파일을 unused/deprecated로 빠르게 분류하려 했으나, 사용자가 지적한 대로 전체 설계도 기준으로 다시 잡았다.

확정된 작업 원칙:

```text
전체 설계 의도 복원
→ 실제 구현 대조
→ 의도는 유지
→ 잘못 연결된 경로/중복/직접참조/위험구역만 수정
→ 삭제보다 ACTIVE / FUTURE / LEGACY / DEPRECATED 분류 우선
```

---

## 1. generated/manual 정리

확정:
- 사람이 관리하는 override는 `library/manual`
- `generated/maps`는 자동/브라우저용 map 산출물
- `bgg-tag-translations.js`는 ACTIVE 유지

격리:
```text
generated/maps/_DEPRECATED_game-name-aliases.json
generated/maps/_DEPRECATED_mood-tag-rules.json
generated/maps/_DEPRECATED_manual-bgg-matches.json
```

이 파일들은 JSON 에러 방지를 위해 `{}` 처리.

---

## 2. paths.js 수정

완료:
- `GAME_CONFIG_TAG_DIR` 오타 `tag` → `tags`
- `OWNED_DIR`
- `OWNED_LEDGER_DIR`
- `OWNED_MASTER_DIR`
- `OWNED_FINAL_DIR`
- final 경로를 `library/owned/final`로 변경
- `LIBRARY_GAMES_DIR` 제거

검증:
```powershell
Select-String -Path game-system/tools/core/paths.js -Pattern "OWNED_FINAL_DIR|LIBRARY_GAMES_DIR"
```

결과:
- `OWNED_FINAL_DIR`만 남음

---

## 3. BGG API / future 상태

`fetch-bgg-details.js`는 FUTURE_API / PENDING.

`convert-bgg.js`에서:
```js
const ENABLE_FETCH_BGG_DETAILS = false;
```

로 정리.

의미:
- API용 구조는 보존
- 현재 공식 실행선에서는 OFF

---

## 4. index.html 오염 제거

`index.html` 상단에 PROJECT_STRUCTURE 설명문이 붙어 있던 문제 제거.

첫 줄:
```html
<!DOCTYPE html>
```

정상.

---

## 5. package.json scripts

scripts 추가.

```json
{
  "scripts": {
    "build": "node game-system/tools/build/build-cottage-game-data.js",
    "convert": "node game-system/tools/convert-bgg.js",
    "convert:xlsx": "node game-system/tools/source/convert-owned-xlsx.js",
    "match:auto": "node game-system/tools/match/auto-resolve-bgg-matches.js",
    "fetch:bgg": "node game-system/tools/fetch/fetch-bgg-details.js"
  },
  "dependencies": {
    "exceljs": "^4.4.0"
  }
}
```

주의:
- PowerShell 실행 정책 때문에 `npm run build`가 막힐 수 있음
- 현재는 `node ...` 명령 사용

---

## 6. shelf system 연결 완료

목표:
- 프론트가 책장명을 계산하지 않게 함
- build 단계에서 `shelfGroupId`, `shelfLabel`, `shelfFullLabel` 생성

수정:
- `shelf-groups.js` CommonJS 정리
- `build-cottage-game-data.js`에서 shelfInfo 생성
- final 데이터에 필드 추가

중요 이슈:
- 처음에는 `node build-cottage-game-data.js`를 실행해도 아무 반응이 없었음
- 원인: 파일이 export만 하고 직접 실행 코드가 없었음

해결:
```js
if (require.main === module) {
  buildCottageGameData();
}
```

검증:
```text
[SHELF_CHECK] 1862 이스턴 카운티 전략 heavy_strategy {
  shelfGroupId: 'heavy_strategy',
  shelfLabel: '헤비 전략게임',
  shelfFullLabel: '헤비 전략게임'
}
```

최종:
- 임시 로그 삭제
- build 실행
- `cottage-games-data.js`에서 `shelfFullLabel` 정상 출력 확인

---

## 7. owned/ledger/master/final 구조 확정

최종 구조:

```text
game-system/game-data/library/
├─ owned/
│  ├─ ledger/
│  ├─ master/
│  └─ final/
│
├─ manual/
└─ images/
```

의미:
```text
ledger = 사람이 직접 보는 Excel 원장
master = 자동보강 + override merge된 내부 기준 JSON
final = 서비스가 신뢰하는 최종 JS/JSON
manual = override 조각
images = 이미지 파일
```

---

## 8. final 데이터 이동

기존:
```text
library/games/cottage-games-data.json
library/games/cottage-games-data.js
```

새 위치:
```text
library/owned/final/cottage-games-data.json
library/owned/final/cottage-games-data.js
```

이동 완료.

build 확인:
```powershell
node game-system/tools/build/build-cottage-game-data.js
```

정상 출력:
```text
total: 636
json: ...library\owned\final\cottage-games-data.json
js: ...library\owned\final\cottage-games-data.js
```

---

## 9. ledger는 Excel로 확정

중간에 JSON ledger 프로토타입을 만들었으나, 최종 판단 변경.

확정:
```text
ledger = Excel
master = JSON
final = JS/JSON
```

이유:
- 사용자가 직접 열고 관리해야 함
- 기존 카테고리/추천인원/베스트인원/굵은글씨/서식이 중요
- Excel이 운영자 친화적

처리:
- 기존 `source/manual/cottage-owned-games.xlsx`를 복사
- 새 위치:

```text
game-system/game-data/library/owned/ledger/cottage-owned-games-ledger.xlsx
```

시트 확인:
```text
[ '보유게임리스트', '시트6', '시트5', '플텍', '음료' ]
```

핵심 시트:
```text
보유게임리스트
```

---

## 10. 현재 멈춘 지점

`보유게임리스트` 시트의 진짜 헤더 행을 찾는 단계.

1행 확인 결과:
- 헤더가 아니라 안내/필터 행

다음에 실행할 명령:

```powershell
node -e "const ExcelJS=require('exceljs');(async()=>{const wb=new ExcelJS.Workbook();await wb.xlsx.readFile('game-system/game-data/library/owned/ledger/cottage-owned-games-ledger.xlsx');const ws=wb.getWorksheet('보유게임리스트');for(let r=1;r<=10;r++){const vals=ws.getRow(r).values.map(v=>v&&v.richText?v.richText.map(x=>x.text).join(''):v);console.log('ROW',r,vals);}})();"
```

목표:
- 헤더가 몇 행인지 찾기
- `보유게임명` 또는 게임명 헤더 위치 확인
- 이후 게임명만 입력하면 Excel ledger 마지막 줄에 행 추가하는 도구 제작

---

## 11. 다음 방 첫 작업

다음 방에서 바로 진행:

```text
1. 보유게임리스트 시트 1~10행 출력
2. 헤더 행 확인
3. ledger Excel에 게임명만 입력하는 도구 만들기
4. 기존 Excel 양식/굵은글씨/추천인원 구조 보존
5. 입력 도구가 ledger와 master를 어떻게 갱신할지 설계
```

---

## 12. 남은 큰 과제

1. ledger Excel 입력 도구
2. master 스키마 확정
3. ledger → master 생성기
4. master → final build 전환
5. 기존 TSV/normalized 의존 제거
6. final 파일명 정리
7. frontend final 경로 연결 검사
8. auto-tag-rule active/pending 정리
9. BGG API 승인 후 fetch 연결
10. 새 게임명 입력 → 자동보강 → 홈페이지 반영 자동화
11. 핸드폰에서도 관리 가능한 입력 UI/서버 구조 검토

---

## 13. 작업 방식

사용자 선호:
```text
명령어 복붙
→ 실행
→ 결과 전달
```

가능하면:
- VS Code에서 직접 찾게 하지 않기
- PowerShell/Node 명령어로 처리
- 한 번에 한 문제만
- 추측으로 원인 이동하지 않기
- 전체 구조 기준으로 판단
