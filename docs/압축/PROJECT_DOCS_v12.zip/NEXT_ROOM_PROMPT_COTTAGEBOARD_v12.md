# NEXT_ROOM_PROMPT_COTTAGEBOARD_v12.md

이전 방에서 코티지보드 홈페이지/게임데이터 구조 안정화 작업을 진행했고, 현재 구조를 `owned/ledger/master/final` 생애주기 기준으로 재정리했다.

현재 확정된 구조:

```text
game-system/game-data/library/
├─ owned/
│  ├─ ledger/
│  │  └─ cottage-owned-games-ledger.xlsx
│  ├─ master/
│  └─ final/
│     ├─ cottage-games-data.json
│     └─ cottage-games-data.js
│
├─ manual/
└─ images/
```

의미:

```text
ledger = 사람이 직접 보는 Excel 원장
master = 자동보강 + override merge된 내부 기준 JSON
final = 서비스가 신뢰하는 최종 데이터
manual = override 조각
images = 이미지 파일
```

완료된 것:
- generated/manual 중복 파일 일부 `_DEPRECATED_` 격리
- `paths.js`의 `tag` → `tags` 오타 수정
- `owned/ledger/master/final` 경로 등록
- final 출력 경로를 `library/owned/final`로 이동
- `build-cottage-game-data.js` 단독 실행 가능하게 수정
- shelf system build 연결 완료
- `shelfGroupId`, `shelfLabel`, `shelfFullLabel` final 데이터에 정상 출력 확인
- BGG API fetch는 future/pending으로 유지하고 현재 공식 실행에서는 off
- ledger는 JSON이 아니라 Excel로 확정
- `source/manual/cottage-owned-games.xlsx`를 복사해서 `owned/ledger/cottage-owned-games-ledger.xlsx` 생성
- ledger Excel 시트 확인 결과:
  `[ '보유게임리스트', '시트6', '시트5', '플텍', '음료' ]`

현재 멈춘 지점:
- `보유게임리스트` 시트의 진짜 헤더 행을 찾는 단계
- 1행은 헤더가 아니라 안내/필터 행으로 확인됨

다음 작업:
1. `보유게임리스트` 시트 1~10행을 출력해서 헤더 행 확인
2. 게임명만 입력하면 ledger Excel에 새 행 추가하는 도구 만들기
3. 기존 Excel 양식/카테고리/추천인원/베스트인원/굵은글씨 구조 최대한 보존
4. 입력 도구가 ledger와 master를 어떻게 갱신할지 설계
5. master 스키마 확정 후 ledger → master 생성기 만들기
6. 이후 master → final build 구조로 전환

바로 실행할 명령:

```powershell
node -e "const ExcelJS=require('exceljs');(async()=>{const wb=new ExcelJS.Workbook();await wb.xlsx.readFile('game-system/game-data/library/owned/ledger/cottage-owned-games-ledger.xlsx');const ws=wb.getWorksheet('보유게임리스트');for(let r=1;r<=10;r++){const vals=ws.getRow(r).values.map(v=>v&&v.richText?v.richText.map(x=>x.text).join(''):v);console.log('ROW',r,vals);}})();"
```

작업 방식:
- 가능하면 VS Code에서 직접 찾게 하지 말고 PowerShell/Node 명령어 제공
- 사용자는 명령어 복붙 → 실행 → 결과 전달
- 한 번에 한 문제만
- 전체 구조 기준으로 판단
- 추측으로 원인 이동하지 말 것
