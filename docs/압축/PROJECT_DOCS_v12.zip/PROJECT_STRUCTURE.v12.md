# PROJECT_STRUCTURE.v12.md

# Cottageboard 홈페이지 / 게임 데이터 시스템 구조 v12

기준: 2026-05-21  
목적: 다음 채팅방에서 현재 구조를 그대로 이어가기 위한 canonical 구조 문서

---

## 0. 작업 원칙

이번 구조 정리는 단순 청소가 아니다.

목표는:

```text
기존 설계 의도 복원
→ 실제 구현 대조
→ 의도는 살리고
→ 잘못 연결된 경로 / 중복 / 직접참조 / 위험구역만 수정
→ ledger / master / final 데이터 생애주기 구조로 안정화
```

새 방에서도 이 원칙을 유지한다.

---

## 1. 확정된 데이터 생애주기

```text
입력 도구 / Excel 원장
↓
owned/ledger
↓
owned/master
↓
owned/final
↓
frontend
```

의미:

```text
ledger = 사람이 직접 보는 얇은 보유게임 원장
master = 자동보강 + override merge가 끝난 내부 기준 데이터
final = 서비스가 신뢰하는 최종 완성 데이터
```

중요 판단:

```text
final은 기본적으로 web/mobile/admin 등 플랫폼별로 나누지 않는다.
same final, different rendering 구조를 기본으로 한다.
```

---

## 2. ROOT

```text
cottage-board-site/
├─ index.html
├─ owned-games.html
├─ package.json
├─ assets/
├─ game-system/
└─ PROJECT_*.md
```

---

## 3. frontend

```text
assets/
├─ css/style.css
├─ js/script.js
└─ images/
```

### index.html
- 홈페이지 메인
- 랜딩 / 추천게임찾기 / 헤더 / 메뉴 / 게임 상세 바텀시트
- 상단에 PROJECT_STRUCTURE 설명문이 붙어 있던 오염 제거 완료
- 첫 줄은 반드시 `<!DOCTYPE html>`

### owned-games.html
- 전체 게임 보기 페이지
- 검색 / 정렬 / 필터 / 카드 목록 / 상세 바텀시트

### assets/js/script.js
- `window.gameData` 읽기
- 추천게임 필터 / 전체게임 검색 / 정렬 / 페이지네이션 / 상세 표시
- 원칙: 프론트는 의미 계산보다 표시 담당
- 책장명, 난이도명, 태그명 등은 build/final 단계 값 우선

### assets/css/style.css
- 코티지보드 톤앤매너 유지
- 웜아이보리 / 딥그린 / 브라운 / 둥근 카드 / 선명한 안내판 스타일

---

## 4. game-system

```text
game-system/
├─ config/
├─ game-data/
└─ tools/
```

---

## 5. config

```text
game-system/config/
├─ shelf-groups.js
├─ difficulty-levels.js
├─ game-status.js
├─ ui-config.js
└─ tags/
   ├─ mood-groups.js
   ├─ play-tags.js
   ├─ relationship-tags.js
   └─ tag-utils.js
```

### shelf-groups.js
- 책장/위치 canonical 기준표
- CommonJS 방식으로 변경됨
- `전략`, `파티`, `가족` 같은 원본값을 `heavy_strategy`, `party`, `light_family`로 변환
- build 단계에서 `shelfGroupId`, `shelfLabel`, `shelfFullLabel` 생성 성공 확인

### config/tags/*
- 분위기 / 플레이 / 관계 / 상황 태그 기준
- `paths.js`의 `tag` 오타를 `tags`로 수정 완료

---

## 6. game-data

```text
game-system/game-data/
├─ source/
├─ generated/
└─ library/
```

---

## 6-1. source

```text
game-system/game-data/source/
├─ csv/
└─ manual/
```

역할:
- 외부에서 가져온 원천 데이터 / 이관용 스냅샷

예:
- BGG ranks CSV
- 구글스프레드시트 export
- 과거 Excel / TSV 스냅샷
- 외부 원본 자료

### source/manual/cottage-owned-games.xlsx
- 기존 구글스프레드시트 export 기반 Excel
- 카테고리 / 추천인원 / 베스트인원 / 굵은글씨 / 서식 포함
- 직접 운영 ledger로 옮기지 않고 복사본을 ledger 양식으로 사용

### source/manual/cottage-owned-games.tsv
- 과거 텍스트 export
- Excel 서식 정보가 사라지므로 최상위 원본 부적합
- 아직 일부 흐름에서 참조 가능성 있으므로 바로 삭제 금지

---

## 6-2. generated

```text
game-system/game-data/generated/
├─ cache/
└─ maps/
```

### generated/cache
- 시스템 임시 저장소
- BGG 검색 캐시 / BGG details cache / 자동 후보 cache
- 사람이 직접 수정하지 않는 자동 산출물

### generated/maps
- 브라우저나 build가 쓰는 변환용 map 산출물
- `bgg-tag-translations.js`는 ACTIVE 유지
- 프론트에서 실제 사용 중

격리 처리:
```text
_DEPRECATED_game-name-aliases.json
_DEPRECATED_mood-tag-rules.json
_DEPRECATED_manual-bgg-matches.json
```

의미:
- 삭제가 아니라 옛 경로 격리
- JSON 에러 방지를 위해 내용은 `{}`

---

## 6-3. library

최종 방향:

```text
game-system/game-data/library/
├─ owned/
│  ├─ ledger/
│  ├─ master/
│  └─ final/
│
├─ manual/
└─ images/
```

---

## 7. library/owned

### owned/ledger

```text
game-system/game-data/library/owned/ledger/
└─ cottage-owned-games-ledger.xlsx
```

역할:
- 사람이 직접 보는 얇은 보유게임 원장
- Excel 형식 확정
- 기존 `source/manual/cottage-owned-games.xlsx`를 복사해서 생성 완료
- 앞으로 게임명 입력 도구가 이 Excel 원장에 새 행을 추가

현재 확인된 시트:
```text
[ '보유게임리스트', '시트6', '시트5', '플텍', '음료' ]
```

핵심 시트:
```text
보유게임리스트
```

### owned/master

```text
game-system/game-data/library/owned/master/
```

역할:
- 자동보강 + manual override merge가 끝난 내부 기준 데이터
- JSON 예정
- 아직 스키마 확정 전

예정 파일명 후보:
```text
cottage-owned-games-master.json
```

들어갈 후보:
- ledger 기본 정보
- BGG id / 영문명 / 평점 / 난이도 / 인원
- 자동 태그
- 이미지 경로 / 상태
- 수동 override 반영 결과
- sync/enrich 상태

### owned/final

```text
game-system/game-data/library/owned/final/
├─ cottage-games-data.json
└─ cottage-games-data.js
```

역할:
- 서비스가 신뢰하는 최종 완성 데이터
- 프론트가 바로 읽는 데이터
- 기존 `library/games`에서 이동 완료
- `paths.js`에서 `OWNED_FINAL_DIR`로 경로 변경 완료

파일명은 과도기상 기존 이름 유지:
```text
cottage-games-data.json
cottage-games-data.js
```

나중에 후보:
```text
owned-games-final.json
cottage-owned-games-final.json
```

---

## 8. library/manual

```text
game-system/game-data/library/manual/
├─ forced-bgg-overrides.json
├─ game-name-aliases.json
├─ manual-bgg-matches.json
└─ mood-tag-rules.json
```

역할:
- 사람이 직접 고치는 override 조각
- 원본 DB가 아니라 보정 계층

의미:
- `game-name-aliases.json`: 이름 매칭 보정
- `manual-bgg-matches.json`: 수동 BGG 매칭
- `forced-bgg-overrides.json`: 자동 매칭 오답 강제 교정
- `mood-tag-rules.json`: 분위기 태그 수동 규칙

---

## 9. library/images

```text
game-system/game-data/library/images/
```

역할:
- 이미지 파일 저장소
- 이미지 자체는 JSON에 넣지 않음
- master/final에는 이미지 경로/상태/출처만 기록

원칙:
```text
이미지 파일 = images 폴더
이미지 메타 = master/final JSON
```

---

## 10. tools

```text
game-system/tools/
├─ admin/
├─ build/
├─ core/
├─ fetch/
├─ match/
├─ source/
├─ tagging/
└─ legacy/
```

### tools/core/paths.js
프로젝트 경로 canonical 허브.

수정 완료:
- `GAME_CONFIG_TAG_DIR` 오타 `tag` → `tags`
- `OWNED_DIR`
- `OWNED_LEDGER_DIR`
- `OWNED_MASTER_DIR`
- `OWNED_FINAL_DIR`
- final 출력 경로를 `library/owned/final`로 변경

### tools/core/read-write.js
JSON/text read/write 유틸.

주의:
- Windows PowerShell `Set-Content -Encoding UTF8`은 BOM 문제 가능
- JSON 생성은 Node `fs.writeFileSync(..., 'utf8')` 선호

### tools/admin
현재 프로토타입:
- `show-master-games.js`
- `add-owned-game.js`

단, ledger가 Excel로 확정되었으므로 다음 방에서 재정리 필요.

앞으로 목표:
```text
node game-system/tools/admin/add-owned-game.js "게임명"
```

실행 시:
- ledger Excel에 행 추가
- master JSON에 draft/pending record 생성
- 이후 BGG 자동보강 연결

### tools/build/build-cottage-game-data.js
final 데이터 생성기.

수정 완료:
```js
if (require.main === module) {
  buildCottageGameData();
}
```

의미:
- require 시 부품처럼 사용
- 터미널 직접 실행 시 build 수행

shelf 연결 완료:
- `shelfGroupId`
- `shelfLabel`
- `shelfFullLabel`
final 데이터 정상 출력 확인.

현재 출력 경로:
```text
game-system/game-data/library/owned/final/cottage-games-data.json
game-system/game-data/library/owned/final/cottage-games-data.js
```

### tools/source/convert-owned-xlsx.js
- Excel에서 normalized JSON 생성
- 굵은글씨 기반 베스트인원 등 Excel 서식 정보 읽는 핵심 도구
- 앞으로 ledger Excel 기반으로 재정리 가능성 있음

### tools/match
- BGG 매칭
- 현재 보유게임 기준 순회
- BGG CSV 177,050개는 local search source
- 장기적으로 BGG local index 최적화 후보

### tools/fetch/fetch-bgg-details.js
- FUTURE_API / PENDING
- BGG API 승인 전에는 OFF

### tools/tagging/auto-tag-rules.js
- 자동 태그 시스템
- `mergeCottageTags()`는 기존 `cottage` 필드를 보존하는 구조
- shelf 필드가 날아가는 문제의 원인은 아니었음

### tools/legacy
- 과거 실험/구버전 도구
- 바로 삭제하지 않음
- active pipeline과 분리

---

## 11. 다음 작업

새 방에서 바로 이어갈 순서:

1. `보유게임리스트` 시트 1~10행 출력해서 헤더 행 확인
2. Excel ledger에 게임명만 입력해 새 행 추가하는 도구 설계
3. 기존 Excel 양식/굵은글씨/추천인원 구조 보존
4. 입력 도구가 ledger와 master를 어떻게 갱신할지 설계
5. master 스키마 확정
6. `build-owned-master.js` 생성
7. 기존 TSV/normalized 기반 build를 master 기반으로 전환
8. final 파일명 정리
9. frontend 경로 연결 검사
10. 프로젝트 상태 MD 갱신

---

## 12. 새 방 작업 방식

```text
1. 한 번에 한 문제만 정의
2. 현재 상태 확인
3. 수정 이유 설명
4. 가능하면 PowerShell 명령으로 처리
5. 실행 결과 확인
6. 다음 단계 진행
```

사용자는 가능하면:
```text
복붙 + 실행 + 결과 전달
```

어시스턴트는:
- 전체 구조 판단
- 경로 설계
- 위험구역 감시
- canonical source 정리
- 정확한 명령 제공
